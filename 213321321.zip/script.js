// 날짜 표시
function displayDate() {
    const dateBox = document.getElementById("date-box");
    const today = new Date();

    const dayNames = ["일요일","월요일","화요일","수요일","목요일","금요일","토요일"];

    const text = `${today.getFullYear()}.${today.getMonth()+1}.${today.getDate()} · ${dayNames[today.getDay()]}`;
    dateBox.textContent = text;
}

// 시간대 배경 변경
function changeBackgroundByTime() {
    const hour = new Date().getHours();
    const body = document.body;

    if (hour < 12) {
        body.style.background = "linear-gradient(135deg, #b4d5ff, #eef5ff)";
    } else if (hour < 18) {
        body.style.background = "linear-gradient(135deg, #90c2e0, #e1edf7)";
    } else {
        body.style.background = "linear-gradient(135deg, #3b4a6b, #1c2030)";
    }
}

// DB에 저장된 키워드 (원하면 수정 가능)
const keywordDB = {
    "help": "이름, 직업, 생일, MBTI, 좋아하는색, 포지션",
    "이름": "송하영",
    "직업": "가수 / 연예인",
    "생일": "1997년 9월 29일",
    "MBTI": "ISFJ",
    "좋아하는색": "파란색",
    "포지션": "보컬"
};

// 화면에 보이는 키워드 박스 데이터
const keywordsFromDB = Object.keys(keywordDB);

function loadKeywords() {
    const box = document.getElementById("keyword-box");
    keywordsFromDB.forEach(k => {
        const div = document.createElement("div");
        div.className = "keyword-item";
        div.title = k;
        box.appendChild(div);
    });
}

// ─────────────────────────────
// ✨ ChatGPT 스타일 대화 기능
// ─────────────────────────────

function addChatMessage(text, isAI = false) {
    const chatBox = document.getElementById("chat-box");
    const msg = document.createElement("div");
    msg.className = isAI ? "chat-ai" : "chat-user";
    msg.textContent = text;
    chatBox.appendChild(msg);

    // 자동 스크롤
    chatBox.scrollTop = chatBox.scrollHeight;
}

function handleUserInput() {
    const input = document.getElementById("user-input");
    const value = input.value.trim();
    if (!value) return;

    // 유저 메시지 출력
    addChatMessage(value, false);

    // DB에 존재하는 키워드인지 확인
    if (keywordDB[value]) {
        addChatMessage(keywordDB[value], true);
    } else {
        addChatMessage("저장되어있지 않은 정보입니다. 'help'를 입력해 사용가능한 키워드 확인.", true);
    }

    input.value = "";
}

document.getElementById("send-btn").addEventListener("click", handleUserInput);
document.getElementById("user-input").addEventListener("keypress", e => {
    if (e.key === "Enter") handleUserInput();
});

// 실행
displayDate();
changeBackgroundByTime();
loadKeywords();
